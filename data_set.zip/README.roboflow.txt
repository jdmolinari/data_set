
poholes - v1 2022-02-01 1:34pm
==============================

This dataset was exported via roboflow.ai on February 1, 2022 at 6:35 PM GMT

It includes 665 images.
Poholes are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


