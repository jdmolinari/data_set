
pothole - v2 2022-02-02 6:23pm
==============================

This dataset was exported via roboflow.ai on February 3, 2022 at 4:15 AM GMT

It includes 665 images.
Echo are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


