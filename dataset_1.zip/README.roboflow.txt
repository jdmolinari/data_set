
data_1 - v1 dataset_1
==============================

This dataset was exported via roboflow.ai on February 21, 2022 at 9:21 PM GMT

It includes 247 images.
Pohole are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


