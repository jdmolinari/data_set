
poholes - v1 2022-02-01 1:02pm
==============================

This dataset was exported via roboflow.ai on February 1, 2022 at 6:03 PM GMT

It includes 100 images.
1 are annotated in folder format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


